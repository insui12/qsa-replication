Submission files: QSA_SQJ_manuscript.pdf, QSA_SQJ_Online_Resource_1.pdf (Online Resource 1), QSA_SQJ_Online_Resource_2.zip (Online Resource 2), QSA_SQJ_latex_source.tar.gz.
Build: pdflatex main && bibtex main && pdflatex main && pdflatex main (main.bbl included). online_resource.tex builds Online Resource 1 independently with pdflatex online_resource (twice for references). or1refs.tex contains the generated Online Resource 1 table numbers.
All files are author-created except sn-jnl.cls, sn-apacite.bst (Springer Nature template v3.1, Dec 2024) and the CTAN packages apacite/algorithms/algorithmicx (*.sty).
The four files are also available at https://github.com/insui12/qsa-replication.
